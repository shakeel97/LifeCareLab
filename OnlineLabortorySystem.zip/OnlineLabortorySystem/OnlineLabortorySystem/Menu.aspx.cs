﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineLabortorySystem
{
    public partial class Menu : System.Web.UI.Page
    {
        string UserID = "";
        protected string Url = "",RptUrl;
        protected void Page_Load(object sender, EventArgs e)
        {
            string UserID = Request.QueryString["rol"];
            if (UserID != "" && UserID != null)
               // logout.Visible = true;
            Url = "TestMenu.aspx?rol=" + UserID;
            if(UserID =="1")                           
                RptUrl="Menu.aspx?rol=" + UserID;
            else
                RptUrl = "Reprt.aspx?rol=" + UserID;

        }
    }
}
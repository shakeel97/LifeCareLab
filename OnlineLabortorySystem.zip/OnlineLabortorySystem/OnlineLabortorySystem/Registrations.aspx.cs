﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineLabortorySystem.Models.DatabaseTableAdapters;
using System.Data;

namespace OnlineLabortorySystem
{
    public partial class Registrations : System.Web.UI.Page
    {
        Sp_GetTestCollectionsTableAdapter objTestMenu = new Sp_GetTestCollectionsTableAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int effectedRow = objTestMenu.Sp_InsertRegistrations(txtFullName.Text, txtAddress.Text, txtNumber.Text, txtEmail.Text, txtPassword.Text, Gnder.SelectedItem.Text, txtDate.Text);
            if (effectedRow == 1)
            {
                lblMEssage.Text = "Save Data Successfully.....";
            }
            else
            {
                lblMEssage.Text = "Not Save Data.....";
            }
        }

    }
}
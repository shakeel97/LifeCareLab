﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineLabortorySystem.Models.DatabaseTableAdapters;
using System.Data;
using System.Web.Security;

namespace OnlineLabortorySystem
{
    public partial class AddNewTest : System.Web.UI.Page
    {
        Sp_GetTestCollectionsTableAdapter objTestMenu = new Sp_GetTestCollectionsTableAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            int effectedRows = objTestMenu.Sp_InsertTest(txtName.Value, txtFee.Value);
            if(effectedRows == 1)
            lblMEssage.Text="Save Data...";
            else
                lblMEssage.Text = "Not Save Data...";


        }
    }
}
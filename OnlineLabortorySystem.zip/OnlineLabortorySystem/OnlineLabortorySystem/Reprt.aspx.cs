﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineLabortorySystem.Models.DatabaseTableAdapters;
using System.Data;
using System.Collections;

namespace OnlineLabortorySystem
{

    public partial class Reprt : System.Web.UI.Page
    {
        string UserID = "";
        protected string PID, Name, Time, strDate, Contacts, age, Sex, result;
        Sp_GetTestCollectionsTableAdapter objTestMenu = new Sp_GetTestCollectionsTableAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {
            UserID = Request.QueryString["rol"];
            GenrateReports((UserID));
        }
        public void GenrateReports(string RegId)
        {
            DataTable dtResult = objTestMenu.GetResultByRegId(Convert.ToInt32(RegId));
            //foreach (DataRow itemss in dtResult.Rows)
            //{
            //    result = itemss["Result"].ToString();
            //    if (Convert.ToInt32(result) > 80)
            //        result = "<bodl>" + result+"</bold>";
            gvTest.DataSource = dtResult;
            gvTest.DataBind();
            DataTable dt = objTestMenu.GetRegistrationsCollections();

            DataRow[] drReg = dt.Select("Id=" + RegId.ToString());
            foreach (DataRow items in drReg)
            {
                PID = items["Id"].ToString();
                Name = items["Name"].ToString();
                Contacts = items["PhoneNumber"].ToString();
                age = "28";
                Sex = items["Gender"].ToString();
                Time = DateTime.Now.TimeOfDay.ToString();
                strDate = DateTime.Now.Date.ToShortDateString();
            }

        }
    }
}
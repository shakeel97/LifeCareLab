﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineLabortorySystem.Models.DatabaseTableAdapters;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;

namespace OnlineLabortorySystem
{
    public partial class TestMenu : System.Web.UI.Page
    {
        string UserID;

        string Range, Unit;
        int SelectedID;
        private ImageButton imgUpdate, imgEdit, imgDelete, imgCancel;
        Sp_GetTestCollectionsTableAdapter objTestMenu = new Sp_GetTestCollectionsTableAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {
            //SelectedID =Convert.ToInt32(ddlName.SelectedValue);
            UserID = Request.QueryString["rol"];
            if (!Page.IsPostBack)
            {
                binGridTest();
                BindDropDownListName();

            }
            // BindDropDownListName();
            // BindDropDownListTest(SelectedID);

            //if (UserID != "" && UserID != null)
            //    logout.Visible = true;

            // Url = "TestMenu.aspx?rol=" + UserID;
            if (UserID.Equals("1"))
            {
                addlink.Visible = true;
                dvResult.Visible = true;
                for (int i = 0; i < gvTest.Rows.Count; i++)
                {

                    imgUpdate = (ImageButton)gvTest.Rows[i].FindControl("ImagebtnUpdate");
                    imgEdit = (ImageButton)gvTest.Rows[i].FindControl("imgbtnEdit");
                    imgDelete = (ImageButton)gvTest.Rows[i].FindControl("imgbtnDelete");
                    imgCancel = (ImageButton)gvTest.Rows[i].FindControl("CancelEditMode");
                    imgEdit.Visible = true;
                    imgDelete.Visible = true;
                    imgUpdate.Visible = true;
                    imgCancel.Visible = true;


                }

            }
            else
            {
                addlink.Visible = false;
                for (int i = 0; i < gvTest.Rows.Count; i++)
                {

                    imgUpdate = (ImageButton)gvTest.Rows[i].FindControl("ImagebtnUpdate");
                    imgEdit = (ImageButton)gvTest.Rows[i].FindControl("imgbtnEdit");
                    imgDelete = (ImageButton)gvTest.Rows[i].FindControl("imgbtnDelete");
                    imgCancel = (ImageButton)gvTest.Rows[i].FindControl("CancelEditMode");
                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    imgUpdate.Visible = false;
                    imgCancel.Visible = false;


                }

            }


        }
        private void binGridTest()
        {
            DataTable dtTestcollections = objTestMenu.GetTestCollections();
            gvTest.DataSource = dtTestcollections;
            gvTest.DataBind();

        }

        protected void gvTest_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvTest.EditIndex = e.NewEditIndex;
            binGridTest();

        }

        protected void gvTest_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvTest.EditIndex = -1;
            binGridTest();
        }

        protected void gvTest_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int rolid = Convert.ToInt32(gvTest.DataKeys[e.RowIndex].Values["Id"].ToString());
            int roweffected = objTestMenu.Sp_DeleteTest(rolid);
            binGridTest();

        }

        protected void gvTest_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int rolid = Convert.ToInt32(gvTest.DataKeys[e.RowIndex].Values["Id"].ToString());
            TextBox txtfName = (TextBox)gvTest.Rows[e.RowIndex].FindControl("txtName");
            TextBox txtfee = (TextBox)gvTest.Rows[e.RowIndex].FindControl("txtfee");
            CheckBox status = (CheckBox)gvTest.Rows[e.RowIndex].FindControl("chkSelectTest");
            int roweffected = objTestMenu.Sp_UpdateTest(rolid, txtfName.Text, txtfee.Text);
            gvTest.EditIndex = -1;
            binGridTest();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            // foreach (GridViewRow row in gvTest.Rows)
            ArrayList arrID = new ArrayList();
            for (int i = 0; i < gvTest.Rows.Count; i++)
            {
                CheckBox status = (CheckBox)gvTest.Rows[i].FindControl("chkSelectTest");
                if (status.Checked)
                {

                    int rolid = Convert.ToInt32(gvTest.DataKeys[i].Values["Id"].ToString());
                    DataTable dt = objTestMenu.GetTestCollections();
                    string name = "";
                    string fee = "";
                    string id = "";
                    DataRow[] dr = dt.Select("Id =" + rolid.ToString());
                    foreach (DataRow item in dr)
                    {
                        id = item[0].ToString();
                        name = item[1].ToString();
                        fee = item[2].ToString();
                    }
                    DataTable dtRow = objTestMenu.GetTestDetailsCollectionsByRegID(Convert.ToInt32(UserID));
                    foreach (DataRow item in dtRow.Rows)
                    {
                        arrID.Add(item[3]);

                    }
                    if (!arrID.Contains(id))
                        objTestMenu.Sp_InsertDetailTestInfo(name, fee, id, Convert.ToInt32(UserID));

                }
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (dllTest.SelectedItem.Text == "Complete Blood Count")
            {
                Range = "70-80";
                Unit = "ml/jl";
            }
            else if (dllTest.SelectedItem.Text == "Blood Urea")
            {
                Range = "60-70";
                Unit = "ml/jl";
            }
            else if (dllTest.SelectedItem.Text == "Cross Match")
            {
                Range = "30-40";
                Unit = "ml/jl";
            }
            else if (dllTest.SelectedItem.Text == "Cardiac Enzyme")
            {
                Range = "30-60";
                Unit = "ml/jl";
            }
            int effected = objTestMenu.Sp_InsertResult(txtResult.Text, Convert.ToInt32(ddlName.SelectedValue), dllTest.SelectedItem.Text, Range, Unit);
            if (effected == 1)
            {
                lblSuccessfull.Text = "Saved range with unit  ...";
            }
            else
                lblSuccessfull.Text = "Not saved range  ...";


        }



        private void BindDropDownListName()
        {
            DataTable dtReg = objTestMenu.GetRegistrationsCollections();

            ddlName.DataSource = dtReg;
            ddlName.DataTextField = "Name";
            ddlName.DataValueField = "Id";
            DataBind();
        }

        private void BindDropDownListTest(int idReg)
        {
            DataTable dtDetails = objTestMenu.GetTestDetailsCollectionsByRegID(idReg);
            dllTest.DataSource = dtDetails;
            dllTest.DataTextField = "Name";
            dllTest.DataValueField = "Id";
            DataBind();
        }
        
        protected void ddlName_SelectedIndexChanged(object sender, EventArgs e)
        {
            // int idf = Convert.ToInt32(ddlName.SelectedValue);
            BindDropDownListTest(Convert.ToInt32(ddlName.SelectedValue));

        }

        protected void gvTest_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTest.PageIndex = e.NewPageIndex;


            binGridTest();
            if (UserID.Equals("1"))
            {
                addlink.Visible = true;
                dvResult.Visible = true;
                for (int i = 0; i < gvTest.Rows.Count; i++)
                {

                    imgUpdate = (ImageButton)gvTest.Rows[i].FindControl("ImagebtnUpdate");
                    imgEdit = (ImageButton)gvTest.Rows[i].FindControl("imgbtnEdit");
                    imgDelete = (ImageButton)gvTest.Rows[i].FindControl("imgbtnDelete");
                    imgCancel = (ImageButton)gvTest.Rows[i].FindControl("CancelEditMode");
                    imgEdit.Visible = true;
                    imgDelete.Visible = true;
                    imgUpdate.Visible = true;
                    imgCancel.Visible = true;


                }

            }
            else
            {
                addlink.Visible = false;
                for (int i = 0; i < gvTest.Rows.Count; i++)
                {

                    imgUpdate = (ImageButton)gvTest.Rows[i].FindControl("ImagebtnUpdate");
                    imgEdit = (ImageButton)gvTest.Rows[i].FindControl("imgbtnEdit");
                    imgDelete = (ImageButton)gvTest.Rows[i].FindControl("imgbtnDelete");
                    imgCancel = (ImageButton)gvTest.Rows[i].FindControl("CancelEditMode");
                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    imgUpdate.Visible = false;
                    imgCancel.Visible = false;
                }
            }
        }

        protected void btnGenrateRep_Click(object sender, EventArgs e)
        {

            Response.Redirect("~/Reprt.aspx?rol=" + ddlName.SelectedValue);


        }

        protected void dllTest_SelectedIndexChanged(object sender, EventArgs e)
        {
            dllTest.Items.Clear();
            dllTest.Items.Add(new ListItem("--Select Test--", ""));
            BindDropDownListTest(Convert.ToInt32(ddlName.SelectedValue));
        }

    }
}
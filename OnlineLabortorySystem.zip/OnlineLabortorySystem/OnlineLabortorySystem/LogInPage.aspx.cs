﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OnlineLabortorySystem.Models.DatabaseTableAdapters;
using System.Data;
using System.Web.Security;


namespace OnlineLabortorySystem
{
    public partial class LogInPage : System.Web.UI.Page
    {
        Sp_GetTestCollectionsTableAdapter objTestMenu = new Sp_GetTestCollectionsTableAdapter();
        string UserId = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (AuthenticationUser(txtUserName.Text, txtPassword.Text))
            {
                Session["userId"] = UserId;
                if (UserId != "" && UserId != null)
                {
                    FormsAuthentication.RedirectFromLoginPage("~/Menu.aspx?rol=" + UserId, true);
                    Response.Redirect("~/Menu.aspx?rol=" + UserId);
                }
                else
                {
                    Response.Redirect("~/LogInPage.aspx");
                }
            }
            else
            {
                lblmessage.Text = "Oops!Invalid UserName and Password.......";
            }
        }
        private bool AuthenticationUser(String UserName, String Password)
        {
            DataTable dtlogin = objTestMenu.GetLoginInfo(UserName, Password);
            foreach (DataRow dr in dtlogin.Rows)
            {
                UserId = dr["Id"].ToString();
            }
            if (dtlogin.Rows.Count != 0)
            {
                return true;
            }
            else
                return false;

        }
    }
}